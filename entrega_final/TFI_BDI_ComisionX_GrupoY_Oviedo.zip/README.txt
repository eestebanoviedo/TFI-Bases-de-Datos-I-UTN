================================================================================
TRABAJO FINAL INTEGRADOR (TFI) - BASES DE DATOS I (UTN)
SISTEMA DE GESTIÓN DE LIBROS Y FICHAS BIBLIOGRÁFICAS (SOLUCIÓN HÍBRIDA)
================================================================================

DATOS DEL ALUMNO Y CURSADA:
---------------------------
- Alumno: Esteban Oviedo
- Carrera: Tecnicatura Universitaria en Programación a Distancia
- Materia: Bases de Datos I
- Comisión: [COMPLETAR COMISIÓN]
- Grupo: [COMPLETAR GRUPO]
- Repositorio GitHub Base: https://github.com/eestebanoviedo/Trabajo-Final-Integrador---Programacion-2
- Enlace al Video de Defensa Oral (10 a 15 min): [INSERTAR ENLACE AL VIDEO AQUÍ]

================================================================================
1. CONTENIDO DEL PAQUETE DE ENTREGA
================================================================================
El presente archivo ZIP contiene todos los recursos necesarios para reproducir
las cinco etapas del TFI de forma controlada y determinística:

/sql/
  01_esquema.sql               -> [Obligatorio] DDL con PK, FK, UNIQUE y CHECKs de dominio.
  01_pruebas_restricciones.sql -> [Auxiliar] Validación de inserciones correctas y fallidas (Errores 3819, 1062, 1452).
  02_catalogos.sql             -> [Obligatorio] Vocabularios y tablas semilla auxiliares para generación.
  03_carga_masiva.sql          -> [Obligatorio] Poblado en SQL puro de 20.002 registros con relación 1:1 estricta.
  03_verificaciones_consistencia.sql -> [Auxiliar] Consultas de control (0 huérfanos, 0 duplicados 1:1, rangos).
  04_indices.sql               -> [Obligatorio] Creación idempotente de índices secundarios en autor, año y Dewey.
  05_consultas.sql             -> [Obligatorio] 4 consultas analíticas (2 JOIN, 1 GROUP BY/HAVING, 1 subconsulta).
  05_explain.sql               -> [Obligatorio] Benchmarking con y sin índices (mediana de 3 corridas) y EXPLAIN ANALYZE.
  06_vistas.sql                -> [Obligatorio] 2 vistas seguras para ocultamiento de información sensible y bajas.
  07_seguridad.sql             -> [Obligatorio] Creación del usuario con mínimos privilegios (usr_biblioteca_app).
  07_pruebas_seguridad.sql     -> [Auxiliar] Pruebas de accesos permitidos y comandos denegados (Error 1142).
  08_transacciones.sql         -> [Obligatorio] Demostración de transacciones ACID en SQL (COMMIT y ROLLBACK).
  09_concurrencia_guiada.sql   -> [Obligatorio] Guion interactivo en dos sesiones: Deadlock (Error 1213) y Aislamiento.

/src/
  config.properties            -> Parámetros de conexión JDBC a MySQL local.
  tpi/biblioteca/config/       -> DatabaseConnection (gestión de conexiones).
  tpi/biblioteca/entities/     -> Entidades Libro, FichaBibliografica y BaseEntity.
  tpi/biblioteca/dao/          -> Interfaces y DAOs JDBC seguros con PreparedStatement.
  tpi/biblioteca/service/      -> Servicios de negocio y manejo de Retry ante Deadlock.
  tpi/biblioteca/main/         -> Menú interactivo original por consola de Programación II.
  tpi/biblioteca/demo/
    DemoSqlInjection.java      -> Demostración de mitigación de SQL Injection con PreparedStatement (Etapa 4).
    DemoDeadlockRetry.java     -> Demostración multihilo de Deadlock y recuperación automática con backoff (Etapa 5).

/lib/
  mysql-connector-j-9.5.0.jar  -> Driver oficial de conectividad MySQL Connector/J.

================================================================================
2. GUÍA DE REPRODUCCIÓN PASO A PASO
================================================================================

REQUISITOS PREVIOS:
- Servidor MySQL 8.0+ o MySQL 9.x en ejecución en localhost:3306.
- Java JDK 21 o superior instalado.

A) EJECUCIÓN SECUENCIAL DE SCRIPTS SQL (DESDE TERMINAL O MYSQL WORKBENCH):
--------------------------------------------------------------------------
Ejecutar los scripts en orden estricto:

  1. Crear esquema y restricciones:
     mysql -u root -p < sql/01_esquema.sql

  2. Validar pruebas de restricciones (opcional):
     mysql -u root -p tpi_biblioteca < sql/01_pruebas_restricciones.sql

  3. Cargar catálogos semilla:
     mysql -u root -p tpi_biblioteca < sql/02_catalogos.sql

  4. Ejecutar carga masiva de datos (20.000+ filas):
     mysql -u root -p tpi_biblioteca < sql/03_carga_masiva.sql

  5. Ejecutar verificaciones de consistencia:
     mysql -u root -p tpi_biblioteca < sql/03_verificaciones_consistencia.sql

  6. Crear índices secundarios de optimización:
     mysql -u root -p tpi_biblioteca < sql/04_indices.sql

  7. Ejecutar consultas complejas de negocio:
     mysql -u root -p tpi_biblioteca < sql/05_consultas.sql

  8. Ejecutar comparativas de rendimiento (EXPLAIN ANALYZE):
     mysql -u root -p tpi_biblioteca < sql/05_explain.sql

  9. Crear vistas de seguridad:
     mysql -u root -p tpi_biblioteca < sql/06_vistas.sql

  10. Crear usuario con privilegios mínimos:
      mysql -u root -p tpi_biblioteca < sql/07_seguridad.sql

  11. Probar accesos permitidos y denegados con el nuevo usuario:
      mysql -u usr_biblioteca_app -pAppPass123! tpi_biblioteca < sql/07_pruebas_seguridad.sql

  12. Ejecutar transacciones SQL de prueba (COMMIT / ROLLBACK):
      mysql -u root -p tpi_biblioteca < sql/08_transacciones.sql

  13. Simulación interactiva de Deadlock en 2 sesiones y Aislamiento:
      Seguir el guion paso a paso detallado en sql/09_concurrencia_guiada.sql abriendo
      dos ventanas simultáneas de MySQL CLI o pestañas de MySQL Workbench.

B) COMPILACIÓN Y EJECUCIÓN DE PRUEBAS HÍBRIDAS EN JAVA:
-------------------------------------------------------
Desde la raíz del proyecto:

  1. Compilar clases:
     javac -cp "lib/mysql-connector-j-9.5.0.jar:src" $(find src -name "*.java")

  2. Demostración Anti-SQL Injection (Etapa 4):
     java -cp "lib/mysql-connector-j-9.5.0.jar:src" tpi.biblioteca.demo.DemoSqlInjection

  3. Demostración Concurrente de Deadlock y Retry Automático (Etapa 5):
     java -cp "lib/mysql-connector-j-9.5.0.jar:src" tpi.biblioteca.demo.DemoDeadlockRetry

================================================================================
FIN DE LAS INSTRUCCIONES
================================================================================
