=============================================================================
TRABAJO FINAL INTEGRADOR (TFI) - BASES DE DATOS I (UTN)
Sistema de Gestion de Libros y Fichas Bibliograficas
=============================================================================

Alumno: Esteban Oviedo
Carrera: Tecnicatura Universitaria en Programacion a Distancia
Materia: Bases de Datos I
Ano: 2026

-----------------------------------------------------------------------------
1. CONTENIDO DEL PAQUETE ZIP
-----------------------------------------------------------------------------
El presente archivo ZIP contiene la totalidad de los recursos de codigo y
scripts exigidos por la catedra:

* sql/
  - 01_esquema.sql: Definicion DDL de tablas y restricciones (PK, FK, UNIQUE, CHECK).
  - 01_pruebas_restricciones.sql: Pruebas de insercion validas y rechazos por error.
  - 02_catalogos.sql: Vocabularios semilla para generacion de datos.
  - 03_carga_masiva.sql: Carga masiva de 20.000 filas con SQL puro.
  - 03_verificaciones_consistencia.sql: Validacion de claves huerfanas y cardinalidad 1:1.
  - 04_indices.sql: Creacion idempotente de indices secundarios.
  - 05_consultas.sql: Las 4 consultas de negocio (JOIN, agrupaciones y subconsulta).
  - 05_explain.sql: Mediciones comparativas de rendimiento con EXPLAIN ANALYZE.
  - 06_vistas.sql: Definicion de las 2 vistas seguras.
  - 07_seguridad.sql: Creacion del usuario de aplicacion usr_biblioteca_app.
  - 07_pruebas_seguridad.sql: Comprobacion de operaciones permitidas y denegadas (Error 1142).
  - 08_transacciones.sql: Demostracion de COMMIT y ROLLBACK atómicos en SQL.
  - 09_concurrencia_guiada.sql: Protocolo paso a paso para dos terminales (Deadlock y Aislamiento).

* src/
  - Codigo fuente Java 21+ con JDBC nativo organizado en capas:
    config, entities, dao, service, main y demo.
  - DemoSqlInjection.java: Demostracion de prevencion de SQL Injection.
  - DemoDeadlockRetry.java: Simulacion multihilo con retry ante Error 1213.

* lib/
  - mysql-connector-j-9.5.0.jar: Driver JDBC oficial de MySQL.

-----------------------------------------------------------------------------
2. ORDEN DE EJECUCION DE LOS SCRIPTS SQL
-----------------------------------------------------------------------------
Ejecutar los scripts en orden en MySQL local (puerto 3306):

1. mysql -u root -p < sql/01_esquema.sql
2. mysql -u root -p tpi_biblioteca < sql/01_pruebas_restricciones.sql
3. mysql -u root -p tpi_biblioteca < sql/02_catalogos.sql
4. mysql -u root -p tpi_biblioteca < sql/03_carga_masiva.sql
5. mysql -u root -p tpi_biblioteca < sql/03_verificaciones_consistencia.sql
6. mysql -u root -p tpi_biblioteca < sql/04_indices.sql
7. mysql -u root -p tpi_biblioteca < sql/05_consultas.sql
8. mysql -u root -p tpi_biblioteca < sql/05_explain.sql
9. mysql -u root -p tpi_biblioteca < sql/06_vistas.sql
10. mysql -u root -p tpi_biblioteca < sql/07_seguridad.sql
11. mysql -u usr_biblioteca_app -pAppPass123! tpi_biblioteca < sql/07_pruebas_seguridad.sql
12. mysql -u root -p tpi_biblioteca < sql/08_transacciones.sql
13. Seguir el instructivo de sql/09_concurrencia_guiada.sql en 2 terminales.

-----------------------------------------------------------------------------
3. COMPILACION Y EJECUCION DE LAS DEMOS JAVA
-----------------------------------------------------------------------------
Desde la raiz del proyecto descompromido:

1. Compilar clases:
   javac -cp "lib/mysql-connector-j-9.5.0.jar:src" -d bin src/tpi/biblioteca/**/*.java

2. Copiar configuracion:
   cp src/config.properties bin/

3. Ejecutar demo de SQL Injection:
   java -cp "lib/mysql-connector-j-9.5.0.jar:bin" tpi.biblioteca.demo.DemoSqlInjection

4. Ejecutar demo de Deadlock y Retry:
   java -cp "lib/mysql-connector-j-9.5.0.jar:bin" tpi.biblioteca.demo.DemoDeadlockRetry
